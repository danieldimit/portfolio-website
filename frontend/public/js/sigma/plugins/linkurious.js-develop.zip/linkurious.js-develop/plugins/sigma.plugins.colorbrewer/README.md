sigma.plugins.colorbrewer
==================

Plugin developed by [Sébastien Heymann](https://github.com/sheymann) for [Linkurious](https://github.com/Linkurious).

Contact: seb@linkurio.us

---
This plugin provides the color specifications and designs developed by [Cynthia Brewer](http://colorbrewer2.org/).

See the [file format](http://bl.ocks.org/mbostock/5577023) for a comprehensive guide of the colorbrewer palette.
